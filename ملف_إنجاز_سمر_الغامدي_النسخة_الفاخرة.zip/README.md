# ملف إنجاز سمر الغامدي — النسخة الفاخرة

ارفعِي `index.html` إلى مستودع GitHub ثم:
Settings → Pages → Deploy from branch → main → / (root) → Save.

النسخة تتضمن QR واحدًا لشواهد الأداء الوظيفي وQR واحدًا لملف إنجاز الطالبات، مع روابط مباشرة.
